#define NICKSERV_LOGIN
#include "identify.c"

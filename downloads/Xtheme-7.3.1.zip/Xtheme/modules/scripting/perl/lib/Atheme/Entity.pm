package Atheme::Entity;

use strict;
use warnings;

use Atheme::Object;

our @ISA = qw/Atheme::Object/;

1;
